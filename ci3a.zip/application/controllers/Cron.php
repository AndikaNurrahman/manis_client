<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cron extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct(); // you have missed this line.
		$this->load->database();

		$this->load->library('curl');
	}

	public function cron()
	{
		date_default_timezone_set("Asia/Jakarta");

		$this->db->select('*');
		$this->db->join('paket', 'pelanggan.paket = paket.paket_id');
		$client = $this->db->get('pelanggan');


		$ipstatic = $this->db->get('pelanggan');
		foreach ($client->result() as $baris) {



			if ($baris->tempo == date('d')) {
				$this->db->where('text_id', '1');
				$text = $this->db->get('text');
				$textdb = $text->row();
				$id = $baris->idp;
				$nama = $baris->nama;
				$nomor = $baris->nomor;
				$paket = $baris->paket_id;
				$tarif = $baris->tarif;
				$pembayaran = "MANUAL";



				for ($i = 0; $i < count(array($id)); $i++) {


					$this->db->where('id_pelanggan', $id);
					$this->db->where('month(tanggal)', date('m'));
					$query  = $this->db->get('tagihan');
					$kontol = $id[$i];
				}
				$i++;
				if ($query->num_rows() >  0) {
					echo $kontol;
					return false;
				} else {
					$data = [
						'id_pelanggan' => $id,
						'no_pelanggan' => $nomor,
						'nama_pelanggan' => $nama,
						'status_code' => 0,
						'paket' => $paket,
						'tarif_inv' => $tarif,
						'pembayaran' => $pembayaran
					];

					$input = $this->db->insert('tagihan', $data);
					$datas = [
						'pesan' => 'Tagihan Baru </span> ' . $nama . ' telah jatuh tempo',
						'status' => 0
					];
					$input = $this->db->insert('aktifasi', $datas);
					$message = $textdb->text_wa;
					$phone = $baris->nomor;


					Apiwa($phone, $message);
					if ($input) {
						echo 'Done';
					} else {

						echo 'Tidak Tersimpan';
					}
				}
			}
		}
	}
}
