<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
{
    parent::__construct();// you have missed this line.
 $this->load->library('session');
 $this->load->database();
   
}   
	public function index()
	{

 		$API = new Mikweb();
	
$user = $_SESSION['user_name'];
$ip = $_SESSION['mkipadd'];
$mkuser =$_SESSION['mkuser'];
$mkpass =$_SESSION['mkpassword'];


	$data['session'] =  $_SESSION;
		$data['title'] = 'Dashboard';
		

$this->load->view('/_template/header',$data);
		$this->load->view('/_template/navbar',$data);
		$this->load->view('/_template/sidebar',$data);

		$this->load->view('/phone/index',$data);

		$this->load->view('/_template/footer');
	}

	public function tambah(){

		$nama=$_POST["nama"];
$password=$_POST["password"];
$tempo=$_POST["jth_tempo"];
$nomor=$_POST["no"];
$mode=$_POST["mode"];
 
 $this->db->get('pelanggan');

$this->db->where('nama', $nama);
    $query = $this->db->get();

    if ( $query->num_rows() >  0)
    {
	echo "Data sudah ada";
	} else {
		
	

  
  $data = array(
        'nama' => $nama,
        'password' => $password,
        'tempo' => $tempo,
        'nomor' => $nomor,
        'tempo' => $mode
);

$this->db->insert( 'pelanggan', $data);
	if ($input) {
		echo"Data berhasil disimpan";
		} 
			echo"Data gagal disimpan";
		}
	}

	public function lihat(){

$this->db->from('pelanggan');
$query = $this->db->get();
foreach ($query->result() as $row)
{
        echo $row->id;
        echo $row->nama;
        echo $row->password;
        echo $row->tempo;
        echo $row->nomor;
        echo '||';

}

	}

	}

