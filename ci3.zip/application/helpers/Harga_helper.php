<?php
function Harga($code){
$url = 'https://portalpulsa.com/api/connect/';

$header = array(
'portal-userid: useridAnda',
'portal-key: keyAnda', // lihat hasil autogenerate di member area
'portal-secret: secretAnda', // lihat hasil autogenerate di member area
);

$data = array(
'inquiry' => 'HARGA', // konstan
'code' => $code, // pilihan: pln, pulsa, game
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_POSTREDIR, CURL_REDIR_POST_ALL);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$result = curl_exec($ch);

echo $result;
}