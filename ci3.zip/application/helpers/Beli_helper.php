<?php
function Beli($nomor,$kode,$id){
$url = 'https://portalpulsa.com/api/connect/';

$header = array(
'portal-userid: useridAnda',
'portal-key: keyAnda', // lihat hasil autogenerate di member area
'portal-secret: secretAnda', // lihat hasil autogenerate di member area
);

$data = array(
'inquiry' => 'I', // konstan
'code' => $nomor, // kode produk
'phone' => $kode,, // nohp pembeli
'idcust' => $id, // Diisi jika produk memerlukan IDcust seperti: Unlock/Aktivasi Voucher, Game Online (FF, ML, PUBG, dll)
'trxid_api' => 'xxxx', // Trxid / Reffid dari sisi client
'no' => '1', // untuk isi lebih dari 1x dlm sehari, isi urutan 1,2,3,4,dst
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_POSTREDIR, CURL_REDIR_POST_ALL);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$result = curl_exec($ch);

echo $result;
}