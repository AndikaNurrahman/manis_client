<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Phone extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
{
    parent::__construct();// you have missed this line.
 $this->load->library('session');
 $this->load->database();
   
}   
	public function index($kunci)
	{
$key = "monsteridiot1928";
			
		if ($kunci!=$key) {
			redirect("dashboard");
				return false;
		}
		
			
    			$this->db->where('mode','ipstatic');
		$query1 = $this->db->get('pelanggan');
		$this->db->where('mode','pppoe');
$query = $this->db->get('pelanggan');
echo '  SEMUA  ';
		echo $this->db->count_all('pelanggan');
		echo '  user  ';
		echo '||';
		echo '  PPPOE  ';
		echo $query->num_rows();
		echo '  user  ';
		echo '||';
		echo '  IPSTATIC  ';
		echo $query1->num_rows();
echo '  user  ';

$this->db->where('paket','2');
$query = $this->db->get('pelanggan');
$jumlah = $query->num_rows();
$paket2 =150000*$jumlah;
$this->db->where('paket','1');
$query = $this->db->get('pelanggan');
$paket1 =100000*$jumlah;
echo '||';
echo 'RP. ';
echo $paket1+$paket2;
$this->db->where('lunas','1');
$query = $this->db->get('pelanggan');
echo '||';
echo $query->num_rows();
$this->db->where('lunas','0');
$query = $this->db->get('pelanggan');
echo '||';
echo $query->num_rows();	
	
	


		

}

	

	public function tambah($kunci){


// grab values as you would from an ordinary $_GET superglobal array associative index.

	
	$key = "monsteridiot1928";
			
		if ($kunci!=$key) {
			redirect("dashboard");
				return false;
		}
$password=$_POST["password"];
$nama=$_POST["nama"];
$tempo=$_POST["tempo"];
$nomor=$_POST["nomor"];
$mode=$_POST["mode"];
$paket=$_POST["paket"];


$this->db->where('nama', $nama);
  $query  = $this->db->get('pelanggan'); 



    if ( $query->num_rows() >  0)
    {
	echo "Data sudah ada";
	}  else {
		  $data = array(
        'nama' => $nama,
        'password' => $password,
        'tempo' => $tempo,
        'nomor' => $nomor,
        'mode' => $mode,
        'paket' => $paket,
        'lunas' => 1
);

$input = $this->db->insert( 'pelanggan', $data);
	if ($input) {
			 $data = "Data berhasil disimpan";
		$this->output->set_output($data);
	
		} else {

			$data = "Data gagal disimpan";
			$this->output->set_output($data);
		}
			
	}



	
		
	

  

		
	}

	public function lihat($kunci){

	$key = "monsteridiot1928";
			
		if ($kunci!=$key) {
			redirect("dashboard");
				return false;
		}
		
$this->db->from('pelanggan');
$query = $this->db->get();
foreach ($query->result() as $row)
{
        echo "<b style='text-align: right;' >".$row->id."</b>";
        echo "<br>";
        echo $row->nama;
        echo "    ";
        echo $row->password;
        echo "<br>";
        echo $row->tempo;
        echo "<br>";
        echo $row->nomor;     
         echo "<br>";
         if ($row->paket='2') {
         	echo 'Rp. 150000';
             } elseif ($row->paket='1') {
             	            
         	echo 'Rp. 100000';
         }
        echo "<br>";
        echo $row->mode;
            echo '||';

}

	



	}
	}

